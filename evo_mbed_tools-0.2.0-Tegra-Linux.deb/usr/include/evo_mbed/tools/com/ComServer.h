/**
 * @file ComServer.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Communication Server Interface
 * 
 * @version 1.0
 * @date 2019-10-09
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef EVO_MBED_TOOLS_COM_SERVER_H_
#define EVO_MBED_TOOLS_COM_SERVER_H_

/* Includes ----------------------------------------------------------------------*/

#include <map>

#include <evo_mbed/com/ComDefs.h>
#include <evo_mbed/com/ComDataObject.h>

#include <evo_mbed/tools/can/CANInterface.h>

/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

 namespace evo_mbed
 {

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_com
  * @{
  */

/**
 * @brief Communication Server for Embedded Devices
 * 

  # Overview

  TODO add description

 */
class ComServer
{
public:

  /**
   * @brief Constructor 
   * 
   * @param logging Set to true to enable logging output
   */
  ComServer(const bool logging = false);

  /**
   * @brief Destructor (releases if necessarry)
   */
  ~ComServer(void);

  /**
   * @brief Initializes the communication server
   * 
   * @param can_if_name Name of the can interface e.g. "slcan0"
   * @param com_timeout_ms Default timeout value for communication
   * 
   * @return @ref Result
   */
  const Result init(const std::string& can_if_name,
                    const unsigned int com_timeout_ms = 10u);

  /**
   * @brief Releases components of communication server
   */
  void release(void);

  /**
   * @brief Registers a node id to the communication server
   *        This function has to be called before start()
   * 
   * @param node_id ID to add
   * @return @ref Result
   */
  const Result registerNode(const uint8_t node_id);

  /**
   * @brief Reads a data object via SDO message
   * 
   * @param node_id ID of the client
   * @param object Object to read
   * @param com_error Communication error
   * @param retry_limit 
   * @param timeout_ms Timeout in milliseconds (0 = default timeout)
   * @param retry_limit Number of retries after timeout or communication error 
   * 
   * @return @ref Result 
   */
  const Result readDataObject(const uint8_t node_id,
                              ComDataObject& object,
                              ComMsgErrorCodes& com_error,
                              const unsigned int timeout_ms = 0u,
                              const unsigned int retry_limit = 0u);

  /**
   * @brief Write a data object via SDO message
   * 
   * @param node_id ID of the client
   * @param object Object to write
   * @param com_error Communication error
   * @param timeout_ms Timeout in milliseconds (0 = default timeout)
   * @return @ref Result 
   */
  const Result writeDataObject(const uint8_t node_id,
                               ComDataObject& object,
                               ComMsgErrorCodes& com_error,
                               unsigned int timeout_ms = 0u,
                               const unsigned int retry_limit = 0u);

  /**
   * @brief Get the can interface
   *
   * @return Reference to @ref CANInterface 
   */
  CANInterface& getCANInterface(void);

  /** \brief Check if class is initialized */
  const bool isInitialized(void) const;

#ifndef BUILD_TESTS
private:
#endif

  /**
   * @brief Get the buffer id assigned to the requested node id
   * 
   * @param node_id Node id of the buffer
   * 
   * @return const int Buffer ID or -1 if id is not registered
   */
  const int getBufferID(const uint8_t node_id);

  /**
   * @brief Send a SDO to the client
   * 
   * @param node_id ID of the client
   * @param sdo SDO payload
   * 
   * @return @ref Result
   */
  const Result txSDO(const uint8_t node_id,
                     const ComCANMsg& tx_sdo);

  /**
   * @brief Receive SDO response from client
   * 
   * @param node_id ID of the client
   * @param sdo Received SDO from client
   * @param error_code Received error code from client
   * @param timeout_ms Maximum time to wait for a message
   * 
   * @return const Result 
   */
  const Result rxSDO(const uint8_t node_id,
                     ComCANMsg& sdo,
                     ComMsgErrorCodes& error_code,
                     const unsigned int timeout_ms);

  CANInterface  _can_if; //!< CAN communication interface

  std::map<uint8_t, int> _rx_buffer_list;
  std::mutex             _rx_buffer_list_mut;

  /** \brief Logging option: set to true to enable logging */
  const bool _logging = false; 

  /** \brief Logging module name */
  const std::string _log_module = "ComServer";

  /** \brief Communication timeout standard value */
  unsigned int _com_timeout_ms = 10u;

  std::atomic<bool> _is_initialized; //!< True if init() was called
};

 /**
  * @} 
  */ // evo_mbed_tools_com
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_COM_SERVER_H_ */