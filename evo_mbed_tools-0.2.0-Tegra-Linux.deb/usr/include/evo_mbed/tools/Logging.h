/**
 * @file Logging.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Utils for logging
 *  
 * @version 1.0
 * @date 2019-10-09
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef EVO_MBED_TOOLS_LOGGING_H_
#define EVO_MBED_TOOLS_LOGGING_H_

/* Includes ----------------------------------------------------------------------*/
#include <iostream>
/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_logging
  * @{
  */

/**
 * @brief Info Logging Function
 */
#ifndef LOG_INFO
  #define LOG_INFO(x) \
  { \
    if(_logging) \
      std::cout << "<Info>    " << _log_module << ": " << x << std::endl; \
  }
#endif

#ifndef LOG_WARN
  #define LOG_WARN(x) \
  { \
    if(_logging) \
      std::cout << "<Warning> " << _log_module << ": " << x << std::endl; \
  }
#endif

#ifndef LOG_ERROR
  #define LOG_ERROR(x) \
  { \
    if(_logging) \
      {std::cout << "<Error>   " << _log_module << ": " << x \
         << " ( " << __FUNCTION__ << "() )" << std::endl;} \
  }
#endif

 /**
  * @} 
  */ // evo_mbed_tools_makros
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/


#endif /* EVO_MBED_TOOLS_LOGGING_H_ */