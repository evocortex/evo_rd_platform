/**
 * @file CANMsg.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Representation of CAN message
 * 
 * @version 1.0
 * @date 2019-08-20
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_TOOLS_CAN_MSG_H_
#define EVO_MBED_TOOLS_CAN_MSG_H_

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/can/CANDefs.h>

#include <array>
#include <string.h>
#include <linux/can.h>
/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_can
  * @{
  */


/**
 * @brief CAN Message Class
 * 

  # Overview

  TODO add description here
 

 */
class CANMsg
{
public:

  /**
   * @brief Construct a new object
   */
  CANMsg(void);

  /**
   * @brief Construct message from frame
   * 
   * @param frame can_frame
   */
  CANMsg(const can_frame& frame);

  /**
   * @brief Construct a new CANMsg object
   * 
   * @param id CAN-message ID
   * @param dlc Data length of CAN-message in size
   * @param data Reference to data array
   */
  CANMsg(const uint16_t id,
         const uint8_t dlc,
         CANData& data);

  /**
   * @brief Construct a new CANMsg object
   * 
   * @param id CAN-message ID
   * @param dlc Data length of CAN-message in size
   * @param array Pointer to array containing data (8 byte array)
   */
  CANMsg(const uint16_t id,
         const uint8_t dlc,
         const uint8_t* array);
  
  /**
   * @brief Construct a new CANMsg object
   * 
   * @param id ID of the message
   */
  CANMsg(const uint16_t id);

  /**
   * @brief Construct a new CANMsg object with 1 byte
   * 
   * @param id ID of the message
   * @param b0 payload byte
   */
  CANMsg(const uint16_t id,
         const uint8_t b0);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1, 
         const uint8_t b2);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1,
         const uint8_t b2, const uint8_t b3);


  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1,
         const uint8_t b2, const uint8_t b3,
         const uint8_t b4);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1,
         const uint8_t b2, const uint8_t b3,
         const uint8_t b4, const uint8_t b5);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1,
         const uint8_t b2, const uint8_t b3,
         const uint8_t b4, const uint8_t b5,
         const uint8_t b6);

  CANMsg(const uint16_t id,
         const uint8_t b0, const uint8_t b1,
         const uint8_t b2, const uint8_t b3,
         const uint8_t b4, const uint8_t b5,
         const uint8_t b6, const uint8_t b7);

  /**
   * @brief Set message ID
   * 
   * @param id CAN-message ID
   */
  void setID(const uint16_t id);

  /**
   * @brief Set data length code
   * 
   * @param dlc Data length in bytes
   */
  void setDLC(const uint8_t dlc);

  /**
   * @brief Append data to the end of the data array
   * 
   * @param byte Byte to append to data array
   * 
   * @return const int -1: Failed to set, otherwise index 
   */
  const int append(const uint8_t byte);

  /**
   * @brief Get ID of the
   * 
   * @return const uint16_t 
   */
  const uint16_t getID(void) const;

  /**
   * @brief Get the dlc in bytes of the can message
   * 
   * @return const uint8_t DLC
   */
  const uint8_t getDLC(void) const;

  /**
   * @brief Converts can message to can_frame
   * 
   * @return const can_frame 
   */
  const can_frame getCANFrame(void) const;

  /**
   * @brief Elementwise access
   * 
   * @param idx Index [0;7]
   * 
   * @return uint8_t& Reference to data at index position
   */
  uint8_t& operator [](const uint8_t idx);

#ifndef BUILD_TESTS
private:
#endif

  uint16_t  _id  = 0u;  //!< CAN ID of th message
  uint8_t   _dlc = 0u; //!< DLC size of the message in bytes

  /** \brief Array containing can data */
  CANData _data;
};


 /**
  * @} 
  */ // evo_mbed_tools_can
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_CAN_MSG_H_ */