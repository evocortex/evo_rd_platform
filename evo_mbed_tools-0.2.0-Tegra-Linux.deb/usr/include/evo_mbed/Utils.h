/**
 * @file Utils.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief General defines and utilities
 * 
 * @version 1.0
 * @date 2018-12-17
 * 
 * @copyright Copyright (c) 2018
 * 
 */

#ifndef EVO_MBED_UTILS_H_
#define EVO_MBED_UTILS_H_

/* Includes ----------------------------------------------------------------------*/

#if defined(STM32F0)
  #include "stm32f0xx_hal.h"
  #include "stm32f0xx_hal_conf.h"
#elif defined(STM32F3)
  #include "stm32f3xx_hal.h"
  #include "stm32f3xx_hal_conf.h"
#endif

#include <cstdint>
#include <limits>
#include <array>
#include <math.h>
#include <stdbool.h>
/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_utils
  * @{
  */

/**
 * @brief Results of evo_mbed functions used by most sub functions
 */
enum Result
{
  RES_OK              = 0x0000U,  //!< OK
  RES_ERROR           = 0x0001U,  //!< General Error
  RES_HAL_ERROR       = 0x0002U,  //!< Error caused by STM HAL Library
  RES_NOT_INITIALIZED = 0x0003U,  //!< Error: Component is not initialized
  RES_ALREADY_CALLED  = 0x0004U,  //!< Error: Function was already called (e.g. Init() called twice -> call DeInit() first)
  RES_INVALID_PARAMS  = 0x0005U,  //!< Error: Invalid functions set
  RES_OUT_OF_MEMORY   = 0x0006U,  //!< Error: Out of memory (e.g. no space left in an array)
  RES_NO_NEW_DATA     = 0x0007U,  //!< Warning: No new data available (e.g. no new CAN message received)
  RES_COND_NOT_MET    = 0x0008U,  //!< Warning: Conditions not met to call this function successfully
  RES_TIMEOUT         = 0x0009U,  //!< Error: Timeout while processing 
  RES_CRIT_ERROR      = 0xFFFAU   //!< Critical Error
};

/**
 * @brief Namespace of MCAL ( Microcontroller Abstraction Layer )
 * 
 * This namespace defines enum and functions which are related to the hardware of
 * the microcontroller.
 */
namespace MCAL
{

/**
 * @brief Enumeration of GPIO Pins
 */
enum GPIO_Pin
{
  PIN_NONE = ((std::uint16_t)0x0000U),  /* No pin selected   */
  PIN_0    = ((std::uint16_t)0x0001U),  /* Pin 0 selected    */
  PIN_1    = ((std::uint16_t)0x0002U),  /* Pin 1 selected    */
  PIN_2    = ((std::uint16_t)0x0004U),  /* Pin 2 selected    */
  PIN_3    = ((std::uint16_t)0x0008U),  /* Pin 3 selected    */
  PIN_4    = ((std::uint16_t)0x0010U),  /* Pin 4 selected    */
  PIN_5    = ((std::uint16_t)0x0020U),  /* Pin 5 selected    */
  PIN_6    = ((std::uint16_t)0x0040U),  /* Pin 6 selected    */
  PIN_7    = ((std::uint16_t)0x0080U),  /* Pin 7 selected    */
  PIN_8    = ((std::uint16_t)0x0100U),  /* Pin 8 selected    */
  PIN_9    = ((std::uint16_t)0x0200U),  /* Pin 9 selected    */
  PIN_10   = ((std::uint16_t)0x0400U),  /* Pin 10 selected   */
  PIN_11   = ((std::uint16_t)0x0800U),  /* Pin 11 selected   */
  PIN_12   = ((std::uint16_t)0x1000U),  /* Pin 12 selected   */
  PIN_13   = ((std::uint16_t)0x2000U),  /* Pin 13 selected   */
  PIN_14   = ((std::uint16_t)0x4000U),  /* Pin 14 selected   */
  PIN_15   = ((std::uint16_t)0x8000U),  /* Pin 15 selected   */
  PIN_All  = ((std::uint16_t)0xFFFFU)  /* All pins selected */
};

/**
 * @brief Enumeration of Timer Channels
 */
enum TIM_Channel
{
  TIM_CHN_1   = 0x0000U,
  TIM_CHN_2   = 0x0004U,
  TIM_CHN_3   = 0x0008U,
  TIM_CHN_4   = 0x000CU,
  TIM_CHN_ALL = 0x0018U,
  TIM_CHN_NONE= 0xFFFFU
};
}

/**
 * @brief Namespace of evocortex utils
 */
namespace utils
{

/**
 * @brief This functions check if a bit is set in the bit field
 * 
 * @param bit_pos Bit Position (Starting from 0 = 1 Bit)
 * @param bit_field Bit field containing bits
 * @return true Bit is set
 * @return false Bit is not set
 */
inline const bool IsBitSet(const std::uint8_t bit_pos, const std::uint8_t bit_field)
{
  return static_cast<bool>((bit_field & (1U << bit_pos)) >> bit_pos);
}

/**
 * @brief Get the system time in milliseconds
 * 
 * The system tick is incremented every milliseconds. 
 * The maximum value is 2^32 - 1. Overflow after ca. 49 days.
 * 
 * @return const std::uint32_t System Time
 */
inline const std::uint32_t GetSysTimeMSec(void)
{
#if defined(USE_HAL_DRIVER)
  return HAL_GetTick();
#else
  return 0;
#endif
}

/**
 * @brief Get the system time in seconds
 * 
 * @return const float System time in seconds (ms accuracy)
 */
inline const float GetSysTimeSec(void)
{
#if defined(USE_HAL_DRIVER)
  return static_cast<float>(HAL_GetTick()) * 0.001f;
#else
  return 0.0f;
#endif
}

/**
 * @brief Calculate delta of two u16 value (overflow safe) = a - b
 */
inline const int32_t CheckU16Ovf(const int32_t value)
{
  if(value < -0x7FFF) {
    return value + 0xFFFF;
  }
  else if(value > 0x7FFF) {
    return value - 0xFFFF;
  }

  return value;
}

}

/**
 * @brief This makro calls the function (x) and stores its result
 *        if the result is != to RES_OK the makro exits the function
 *        with the result as return value
 */
#define EVO_RET_RESLT_ON_ERR(x)         \
{                                       \
  const evo::Result res_ret_on_err = x; \
  if(evo::RES_OK != res_ret_on_err)     \
  {                                     \
    return res_ret_on_err;              \
  }                                     \
}                                       \

 /**
  * @} 
  */ // evo_mbed_utils
/*--------------------------------------------------------------------------------*/

}; /* evo */

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_UTILS_H_ */

