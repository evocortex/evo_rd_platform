//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file ComDefs.h
 * @author MBA (info@evocortex.com)
 * @brief Defines for communication
 * 
 * @version 1.0
 * @date 2019-04-23
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_COM_DEFS_H_
#define EVO_MBED_COM_DEFS_H_

/* Includes ----------------------------------------------------------------------*/
#include <stdint.h>
/*--------------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_com_defs
  * @{
  */

constexpr uint16_t COM_NUM_OBJECTS      = 53u;  //!< Number of objects in list
constexpr uint8_t  COM_NODE_ID_MIN      = 1u;   //!< Minimum allowed value for node id
constexpr uint8_t  COM_NODE_ID_MAX      = 127u; //!< Maximum allowed value for node id
constexpr uint8_t  COM_SDO_MSG_MIN_SIZE = 4U;   //!< Min size of a SDO message


/**
 * @brief Enumeration of data types a data object can represent
 */
enum ComDataType : uint8_t
{
  COM_DATA_TYPE_NONE   = 0U, //!< No data type specified
  COM_DATA_TYPE_BOOL   = 1U, //!< boolean
  COM_DATA_TYPE_I8     = 2U, //!< int8_t
  COM_DATA_TYPE_I16    = 3U, //!< int16_t
  COM_DATA_TYPE_I32    = 4U, //!< int32_t
  COM_DATA_TYPE_U8     = 5U, //!< uint8_t
  COM_DATA_TYPE_U16    = 6U, //!< uint16_t
  COM_DATA_TYPE_U32    = 7U, //!< uint32_t
  COM_DATA_TYPE_FLOAT  = 8U  //!< float
  /* double type not supported */
};

/**
 * @brief Access type of message
 */
enum ComMsgAccessType : uint8_t
{
  COM_MSG_ACCS_NONE  = 0x00u,  //!< No command defined
  COM_MSG_ACCS_READ  = 0x22u,  //!< Command to read data
  COM_MSG_ACCS_WRITE = 0x40u,  //!< Command to write data
  COM_MSG_ACCS_ERROR = 0x80u   //!< Error response code
};

/**
 * @brief Message Type
 */
enum ComMsgType
{
  COM_MSG_TYPE_NMT     = 0x0u, //!< Network Management
  COM_MSG_TYPE_EMCY    = 0x1u, //!< Emergency Messages
  COM_MSG_TYPE_SDO_TX  = 0xBu, //!< Service Data Object TX
  COM_MSG_TYPE_SDO_RX  = 0xCu, //!< Service Data Object RX
  COM_MSG_TYPE_ERROR   = 0xEu  //!< Error
};

/**
 * @brief Define of error codes
 */
enum ComMsgErrorCodes : uint32_t
{
  COM_MSG_ERR_NONE            = 0x00000000u,  //!< No error present
  COM_MSG_ERR_INVLD_CMD       = 0x05040001u,  //!< Invalid cmd specified
  COM_MSG_ERR_READ_ONLY       = 0x06010002u,  //!< Try to write an read only object
  COM_MSG_ERR_OBJCT_INVLD     = 0x06020000u,  //!< Object ID does not exist
  COM_MSG_ERR_INVLD_DATA_TYPE = 0x06070012u,  //!< Data type invalid
  COM_MSG_ERR_VALUE_RANGE_EXCD= 0x06090030u,  //!< Value not in range
  COM_MSG_ERR_COND_NOT_MET    = 0x06090031u   //!< Conditions not met to execute
};

/**
 * @brief Union of data value
 *        Represents the data of an object as
 *        uint8 to float32
 */
union ComDataDefine
{
  uint8_t   u8[4];  //!< uint8_t representation
  int8_t    i8[4];  //!< uint8_t representation

  uint16_t  u16[2]; //!< uint16_t representation
  int16_t   i16[2]; //!< int16_t representation

  uint32_t  u32;  //!< uint32_t representation
  int32_t   i32;  //!< int32_t representation

  float     f32;  //!< float representation
};

/**
 * @brief Defines the header of a CAN message
 */
#pragma pack(push, 1)
union ComCANMsgHeader
{
  uint16_t    can_id; //!< CAN ID
  struct
  {
    uint8_t    node_id : 7;  //!< ID of the node
    ComMsgType type    : 4;  //!< Type of the message
    uint8_t    n       : 5;  //!< No data
  }Header;
};
#pragma pack(pop)

/**
 * @brief Define of a SDO CAN message
 */
#pragma pack(push, 1)
union ComCANMsg
{
  uint8_t can_data[8];  //!< CAN raw data

  struct
  {
    ComMsgAccessType    access_type : 8;  //!< Access type of the message
    uint16_t            object_id   : 16; //!< Object ID of the message
    ComDataType         data_type   : 8;  //!< Date type of the message
    uint32_t            data        : 32; //!< Data of the message
  }SDO;
};
#pragma pack(pop)

 /**
  * @} 
  */ // evo_mbed_com_defs
/*--------------------------------------------------------------------------------*/

}; /* namespace evo */  

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_COM_DEFS_H_ */
