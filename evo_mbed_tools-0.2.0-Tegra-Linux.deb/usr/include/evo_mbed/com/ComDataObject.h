//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file ComDataObject.h
 * @author MBA (info@evocortex.com)
 * @brief Communication data object
 * 
 * @version 1.0
 * @date 2019-04-13
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_COM_DATA_OBJECT_H_
#define EVO_MBED_COM_DATA_OBJECT_H_

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/com/ComDefs.h>

#ifndef BUILD_MCU
  #include <mutex>
  #include <atomic>
#endif
/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_com_data_object
  * @{
  */


/**
 * @brief Communication data object representation
 */
class ComDataObject
{
public:

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   */
  ComDataObject(const uint16_t id, const bool rw, const ComDataType data_type);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const bool initial_value);
  
  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint8_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int8_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint16_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int16_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint32_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int32_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const float initial_value);

  /**
   * @brief Copy constructor
   * 
   * @param obj Root object
   * 
   */
  ComDataObject(const ComDataObject& obj);

  /**
   * @brief Set the Raw Bytes object
   * 
   * @param byte_list Pointer to array containing data
   * @param size Size of data in array
   */
  void setRawBytes(const uint8_t* byte_list, const uint8_t size);

  /**
   * @brief Sets the data updated flag to true
   */
  void setDataUpdated(void);

  /**
   * @brief Reset data updated flag
   */
  void setDataReaded(void);

  /**
   * @brief Returns the size of the used data type
   * 
   * @return const uint8_t Size of the object in bytes
   */
  const uint8_t getSize() const;

  /* Set operators */
  ComDataObject& operator=(const bool v);
  ComDataObject& operator=(const uint8_t v);  
  ComDataObject& operator=(const int8_t v);
  ComDataObject& operator=(const uint16_t v);
  ComDataObject& operator=(const int16_t v);
  ComDataObject& operator=(const uint32_t v);
  ComDataObject& operator=(const int32_t v);
  ComDataObject& operator=(const float v);

  /* Get operators */
  operator bool();
  operator uint8_t();
  operator int8_t();
  operator uint16_t();
  operator int16_t();
  operator uint32_t();
  operator int32_t();
  operator float(); 

  /* Getters */
  const uint16_t      getID(void)           const;
  const bool          getRW(void)           const;
  const ComDataType   getType(void)         const;
  const bool          getDataUpdated(void)  const;
  const uint32_t      getRawValue(void)     const;

#ifndef BUILD_TESTS
private:
#endif

  const uint16_t      _id;        //!< CAN object ID [0; 65535]
  const bool          _rw;        //!< Read and writable (true: yes false: read only)
  const ComDataType   _type;      //!< Data type of the object

  ComDataDefine       _data;          //!< Data representation
  bool                _data_updated;  //!< True if data was written and not readed

#ifndef MCU_BUILD
  std::mutex          _access_mutex;  //!< Mutex for locking access in multi threaded environment
#endif
};

 /**
  * @} 
  */ // evo_mbed_com_data_object
/*--------------------------------------------------------------------------------*/

}; /* namespace evo_mbed */

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_COM_DATA_OBJECT_H_ */
