//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file CANRxBuffer.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief CAN RX Buffer to store received messages
 * 
 * @version 1.0
 * @date 2019-08-20
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_TOOLS_CAN_RX_BUFFER_H_
#define EVO_MBED_TOOLS_CAN_RX_BUFFER_H_

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/tools/can/CANMsg.h>

#include <iostream>
#include <queue>
#include <mutex>
#include <thread>
#include <atomic>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <net/if.h>
#include <unistd.h>
#include <poll.h>
/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_can
  * @{
  */


/**
 * @brief CAN Receive Buffer
 * 

  # Overview

  TODO add description here
 

 */
class CANRxBuffer
{
public:

  /**
   * @brief Construct of a new rx buffer
   * 
   * @param can_socket CAN socket (already initialized)
   * @param buffer_size Size of the rx buffer (max number of messages)
   * @param can_filter_id CAN-ID filter
   * @param can_filter_mask CAN Mask filter
   */
  CANRxBuffer(const int can_socket,
              const int buffer_size,
              const uint16_t can_filter_id,
              const uint16_t can_filter_mask);

  /**
   * @brief Destructor
   * 
   */
  ~CANRxBuffer(void);

  /**
   * @brief Initializes the buffer (setup filter etc.)
   * 
   * @return true Init successful
   * @return false Error during init
   */
  const bool init(void);

  /**
   * @brief Stops all communication and releases interfaces
   * 
   */
  void release(void);

  /**
   * @brief Starts reception thread
   * 
   * @return true Started successful
   * @return false Failed to start
   */
  const bool start(void);

  /**
   * @brief Stops reception thread
   */
  void stop(void);

  /**
   * @brief Get message from buffer
   * 
   * @param msg Message
   * @return true Message available
   * @return false No messages in buffer
   */
  const bool getMessage(CANMsg& msg);

  /**
   * @brief Get the number of the message in the buffer
   * 
   * @return const unsigned int Number of messages in the buffer
   */
  const unsigned int getNumMessages(void);

  /**
   * @brief Deletes all messages in the buffer
   * 
   * @return true Successfully deleted all messages
   * @return false Error
   */
  const bool clearBuffer(void);

  /**
   * @brief Checks if overflow flag is set. The flag is
   *        set if the messages were not readed fast enough
   *        from the buffer (old messages are lost)
   * 
   * @return true Overflow detected messages were lost
   * @return false No overflow detected
   */
  const bool checkOverflow(void) const;

#ifndef BUILD_TESTS
private:
#endif

  /**
   * @brief Reception handler (thread)
   */
  void rxHandler(void);

  /**
   * @brief Add a received message to the buffer
   * 
   * @param msg New message
   */
  void appendMessage(const CANMsg& msg);

  const int   _can_socket = -1; //!< Linux socket connected to can
  can_filter  _can_filter;      //!< CAN filter
  timeval     _timeout_settigs; //!< Timeout settings during rx

  std::queue<CANMsg> _msg_buffer;       //!< Message buffer
  const unsigned int _msg_buffer_size;  //!< Maximum message buffer size
  std::mutex         _msg_buffer_mutex; //!< Mutex for message buffer

  /** \brief True if communication is running start() was called */
  std::atomic<bool> _running;

  /** \brief Thread for receiving messages */
  std::unique_ptr<std::thread>  _rx_thread;

  /** \brief Stores true if message buffer is overflowed */
  std::atomic<bool> _msg_overflow;

  /** \brief Flag to enable/disable logging output */
  bool _logging = false;

  /** \brief True class is initialized */
  std::atomic<bool> _is_initialized;
};

 /**
  * @} 
  */ // evo_mbed_tools_can
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_CAN_RX_BUFFER_H_ */