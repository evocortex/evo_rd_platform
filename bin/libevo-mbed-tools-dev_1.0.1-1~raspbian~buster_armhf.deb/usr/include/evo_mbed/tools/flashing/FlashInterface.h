//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file FlashInterface.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Interface to flash Evocortex embedded devices
 * 
 * @version 0.1
 * @date 2019-08-20
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */


#ifndef EVO_MBED_TOOLS_FLASH_INTERFACE_H_
#define EVO_MBED_TOOLS_FLASH_INTERFACE_H_

/* Includes ----------------------------------------------------------------------*/

#include <evo_mbed/bootloader/ProductID.h>
#include <evo_mbed/tools/can/CANInterface.h>
#include <evo_mbed/tools/flashing/FlashHexFile.h>

#include <string>
#include <vector>

/*--------------------------------------------------------------------------------*/

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup Flashing_Module
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup FlashInterface
  * @{
  */


/**
 * @brief Class representing a flashable device of Evocortex
 */
struct FlashDevice
{
  /**
   * @brief Default constructor
   */
  FlashDevice() : id(-1), com_id(0), pid(), sw_version(0.0f), updateable(false)  {}

  /**
   * @brief Construct a new Flash Device object
   * 
   * @param id Index in list
   * @param pid Product id @ref ProductID
   */
  FlashDevice(const unsigned int id, const ProductID& pid)  : 
    id(id), com_id(0u), pid(pid), sw_version(0.0f), updateable(false) {}

  unsigned int  id;          //!< Index in list
  unsigned int  com_id;      //!< Communication ID of the node
  ProductID     pid;         //!< Product ID
  float         sw_version;  //!< Software version
  bool          updateable;  //!< Flag if device is updateable
};


/**
 * @brief Flash Interface Class
 * 
 # Overview

 TODO Add description of class

 * 
 */
class FlashInterface
{
public:

  /**
   * @brief Default constructor
   * 
   * @param  logging Enables/disabled log output
   */
  FlashInterface(const bool logging = false);

  /**
   * @brief Destructor
   */
  ~FlashInterface();

  /**
   * @brief Initializes the flash interface\n
   *        - Initialize CAN interface\n
   *        - Init data and submodules\n
   *        Please initialize the evo::logger class first before
   *        calling the init function!
   * 
   * @param can_if_name Name of the can interface
   * 
   * @return true Initialization successful
   * @return false Initialization failed with error
   */
  bool init(const std::string& can_if_name);

/**
  * @brief Releases the flash interface\n
   * 
   */ 
void release();

  /**
   * @brief Opens the HEX file and checks if it is a valid
   *        firmware program of Evocortex
   * 
   * @param file_name Filename of hex file with path
   * 
   * @return true File opened successfully 
   * @return false Error while opening file (not found, general error...)
   */
  bool openHexFile(const std::string& file_name);

    /**
   * @brief Closes the HEX file 
   * 
   * @return true File closed successfully 
   * @return false Error while closing file
   */
  bool closeHexFile();

  /**
   * @brief This function sends the reset into bootloader request via
   *        the CAN interface
   * 
   * @return true Command was send successfully
   * @return false Failed to send command
   */
  bool sendBootlRequest(void);

   /**
   * @brief This function sends the reset request via
   *        the CAN interface
   * 
   * @return true Command was send successfully
   * @return false Failed to send command
   */
  bool sendResetRequest(void);

  /**
   * @brief Scans the can bus for devices in bootloader mode
   * 
   * @param scan_time_duration_s Scanning time in seconds
   * 
   * @return true Scan was successful
   * @return false Scan failed with an error
   */
  bool scanDevices(const double scan_time_duration_s);

  /**
   * @brief Set the communication ID to the selected device
   * 
   * @param idx Index in device list
   * @param id Com ID to set [1;127]
   * @return true 
   * @return false 
   */
  bool setComId(const unsigned int idx,
                const unsigned int id);

  /**
   * @brief Activates the device and enables flash mode
   * 
   * @param idx Index of device in device list
   * 
   * @return true Activation successful
   * @return false Activation failed
   */
  bool activateDevice(const unsigned int idx);

  /**
   * @brief Deactivates the device and disables flash mode
   * 
   * @param idx Index of device in device list
   * 
   * @return true Activation successful
   * @return false Activation failed
   */
  bool deactivateDevice(const unsigned int idx);

  /**
   * @brief Reads 16 bit / 2 byte from the flash of the device
   *        at the requested address
   * 
   * @param addr 32-bit Address in device flash
   * @param data Readed data from flash
   * 
   * @return true Successfully readed the data from flash 
   * @return false Failed to read data from flash
   */
  bool readData(const uint32_t addr,
                      uint16_t& data);

  /**
   * @brief Reads the software version of the device
   *        Take care that @ref activateDevice is called first
   * 
   * @param version [out] Software version
   * 
   * @return true Software version successfully readed
   * @return false Software version read failed
   */
  bool readSWVersion(float& version);

  /**
   * @brief Reads the CRC of the program flash
   * 
   * @param crc [out] CRC of program in flash
   * 
   * @return true Success
   * @return false Error
   */
  bool readCRC(uint32_t& crc);

  /**
   * @brief This function reads the communication ID of the
   *        device
   * 
   * @param id Variable were the communication ID is stored
   * 
   * @return true Success
   * @return false Error
   */
  bool readComId(uint16_t& id);

  /**
   * @brief Update software version and data of all devices
   *        Take car to first call @ref scanDevices
   * 
   * @return true Devices successfully updated
   * @return false Error during update
   */
  bool updateDevices(void);

  /**
   * @brief Flash specific device
   * 
   * @param idx Index of device in @ref _device_list
   * 
   * @return true Success 
   * @return false Error
   */
  bool flashDevice(const unsigned int idx);

  /**
   * @brief Returns the device list found via @ref scanDevices
   * 
   * @return const std::vector<ProductID>& Vector containing all PIDs
   */
  const std::vector<FlashDevice>& getDevList(void) const;


  /**
   * @brief Returns the active device index
   * 
   * @return const unsigned int Active device idx or -1 if no device is active
   */
  unsigned int getActiveDeviceIdx(void) const;

  /**
   * @brief Get the reference to the firmware file
   * 
   * @return const FlashHexFile& const 
   */
  const FlashHexFile& getFirmwareFile(void) const;

  /**
   * @brief Checks if the firmware is compatible with
   *        the specified device
   * 
   * @param idx Index of device in list @ref _device_list
   * 
   * @return true Compatible
   * @return false Incompatible
   */
  bool checkFirmwareCompatible(const unsigned int idx);

  /**
   * @brief Check if flash interface is initialized
   * 
   * @return true Class is initialized @ref init was called
   * @return false Class is not initialized
   */
  bool isInitialized(void) const;
#ifndef BUILD_TESTS
private:
#endif
  /**
   * @brief Sends the command with the desired payload into the
   *        CAN network
   * 
   * @param cmd Command to send see @ref EVO_BootlCmdTypeDef
   * @param payload_u16 16-Bit payload of data
   * @param payload_u32 32-Bit payload of data
   * 
   * @return true Command successfully send to device
   * @return false Error until sending
   */
  bool sendCmd(const EVO_BootlCmdTypeDef cmd,
               const uint16_t payload_u16,
               const uint32_t payload_u32);

  /**
   * @brief Send command with attached ProductID
   * 
   * @param cmd Command to send to can-network
   * @param pid Product ID to attach to message @ref ProductID
   * 
   * @return true   Product ID sucessfuly send
   * @return false  Failed to send product id
   */
  bool sendPID(const EVO_BootlCmdTypeDef cmd,
               const ProductID pid);

  /**
   * @brief Receives the response from the can network after
   *        a command is send to it
   * 
   * @param cmd Received command response see @ref EVO_BootlCmdTypeDef
   * @param payload_u16 Received 16-Bit payload
   * @param payload_u32 Received 32-Bit payload
   * 
   * @return true Successfully received response
   * @return false Error or timeout during receive
   */
  bool receiveCmd(EVO_BootlCmdTypeDef& cmd,
                  uint16_t& payload_u16,
                  uint32_t& payload_u32);

  /**
   * @brief Receives message with product ID from can-network
   * 
   * @param cmd Received command from can-network
   * @param pid Received PID from can-network
   * 
   * @return true Successful received response from network
   * @return false No message received due to can error or timeout
   */
  bool receivePID(EVO_BootlCmdTypeDef& cmd,
                  ProductID& pid);

  /** \brief Maximum time to wait for response in msec */
  const unsigned int _timeout_ms;

  /** \brief Instance of the communication handler */
  evo_mbed::CANInterface  _can_interface;

  /** \brief List containing all devices found */
  std::vector<FlashDevice>  _device_list;

  /** \brief Index in @ _device_list of active device */
  unsigned int _active_dev_idx;

  /** \brief File containing firmware */
  FlashHexFile  _firmware_file;

  /** \brief Logging option: set to true to enable logging */
  const bool _logging = false; 

  /** \brief Logging module name */
  const std::string _log_module = "FlashInterface";

  /** \brief True if class is initialized */
  bool  _is_initialized;
};

 /**
  * @} 
  */ // FlashInterface
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // Flashing_Module
/*--------------------------------------------------------------------------------*/

  /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

};

#endif /* EVO_MBED_TOOLS_FLASH_INTERFACE_H_ */