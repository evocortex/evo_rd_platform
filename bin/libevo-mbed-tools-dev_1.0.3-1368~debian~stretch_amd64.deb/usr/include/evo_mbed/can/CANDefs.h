//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file CANDefs.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief CAN Defines
 * 
 * @version 1.0
 * @date 2019-08-10
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_CAN_DEFS_H_
#define EVO_MBED_CAN_DEFS_H_

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/Utils.h>
/*--------------------------------------------------------------------------------*/

namespace evo_mbed
{ 

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

 /*--------------------------------------------------------------------------------*/
/** @addtogroup CAN_Module
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup CAN_Defines
  * @{
  */

/** \brief Typedefine of CAN data */
typedef std::array<std::uint8_t, 8> CANData;

/** \brief Normal operation mode of CAN driver */
#ifndef CAN_MODE_NORMAL
  #define CAN_MODE_NORMAL 0
#endif

/** \brief Loopback (tx to rx) operation mode of CAN driver */
#ifndef CAN_MODE_LOOPBACK
  #define CAN_MODE_LOOPBACK 1
#endif

/** \brief Silent (no tx) operation mode of CAN driver */
#ifndef CAN_MODE_SILENT
  #define CAN_MODE_SILENT 2
#endif

/** \brief Silent loopback (no tx but to rx) operation mode of CAN driver */
#ifndef CAN_MODE_SILENT_LOOPBACK
  #define CAN_MODE_SILENT_LOOPBACK 3
#endif

/** \brief Default CAN-ID mask, which will setup the filter to check all bits */
constexpr uint16_t CAN_FILTER_DEFAULT_ID_MASK = 0x7FFU;

/**
 * @brief CAN Driver Modes
 */
enum CANMode
{
  CAN_NORMAL           = CAN_MODE_NORMAL,         //!< Normal Mode TX/RX enabled
  CAN_LOOPBACK         = CAN_MODE_LOOPBACK,       //!< Loopback Mode TX messages are rerouted to RX and send
  CAN_SILENT           = CAN_MODE_SILENT,         //!< Silent Mode only RX messages are possible 
  CAN_SILENT_LOOPBACK  = CAN_MODE_SILENT_LOOPBACK //!< Silent Loopback Mode TX messages are rerouted to RX and not send
};

/**
 * @brief CAN Speed
 */
enum CANSpeed
{
  CAN_SPD_100K  = 0U, //!< 100 kBit/s Baudrate
  CAN_SPD_125K  = 1U, //!< 125 kBit/s Baudrate
  CAN_SPD_250K  = 2U, //!< 250 kBit/s Baudrate
  CAN_SPD_500K  = 3U, //!< 500 kBit/s Baudrate
  CAN_SPD_1000K = 4U  //!< 1 MBit/s Baudrate
};

/**
 * @brief RX FIFO Buffers of CAN driver
 */
enum CANRXBuffer
{
  CAN_RX_BUFF0  = 0U, //!< RX FIFO Buffer 0
  CAN_RX_BUFF1  = 1U  //!< RX FIFO Buffer 1
};

  /**
  * @} 
  */ // CAN_Defines
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // CAN_Module
/*--------------------------------------------------------------------------------*/

/**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

}; /* namespace evo_mbed */

#endif /* EVO_MBED_CAN_DEFS_H_ */