//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file Interface.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief CAN Interface used for communication with can devices
 * 
 * @version 1.0
 * @date 2019-08-20
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_TOOLS_CAN_INTERFACE_H_
#define EVO_MBED_TOOLS_CAN_INTERFACE_H_

/* Includes ----------------------------------------------------------------------*/

#include <evo_mbed/tools/can/CANMsg.h>
#include <evo_mbed/tools/can/CANRxBuffer.h>


#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <net/if.h>
#include <unistd.h>

#include <iostream>
#include <string>
#include <cstring>
#include <vector>

#include <thread>
#include <mutex>

/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_can
  * @{
  */


/**
 * @brief CAN Interface Class
 * 

  # Overview

  TODO add description here
 

 */
class CANInterface
{
public:

  /**
   * @brief Construct a new CANInterface object
   * 
   * @param logging Set to true to enable logging output
   */
  CANInterface(const bool logging = false);

  /**
   * @brief Destroy the CANInterface object
   * 
   */
  ~CANInterface(void);

  /**
   * @brief Opens the socket can device and initializes the
   *        sub components of the class
   * 
   * @param if_name Socketcan interface name .e.g. "slcan0"
   * 
   * @return @ref Result
   */
  const Result init(const std::string& if_name);

  /**
   * @brief Release class and all subcomponents and threads
   */
  void release(void);

  /**
   * @brief Adds an rx buffer for the can messages with the specified filter
   *        The assigned ID of the rx buffer is stored into buffer_id
   *        This function is only callable in stopped() mode
   * 
   * @param size Amount of messages which can be buffered
   * @param can_filter_id ID Message ID which must fit to add a message to rx buffer
   * @param can_filter_mask Mask which specifies which bits are checked and which not
   * @param buffer_id Assigned ID for the rx buffer
   * 
   * @return @ref Result
   */
  const Result addRxBuffer(const unsigned int size,
                           const uint16_t can_filter_id,
                           const uint16_t can_filter_mask,
                           int& buffer_id);

  /**
   * @brief Transmits a message via the can network
   * 
   * @param msg Message to send
   * 
   * @return @ref Result
   */
  const Result tx(const CANMsg& msg);

  /**
   * @brief Receives a message in blocking mode 
   * 
   * Note: Take care to specify the can-id you want to receive in
   *       the msg variable
   * 
   * @param msg CAN message containing requested CAN id, data will
   *            be written to the buffer
   * @param timeout_ms Maximum time in msec to wait for message
   * 
   * @return @ref Result
   */
  const Result rx(CANMsg& msg,
                  const unsigned int timeout_ms);

  /**
   * @brief Get the number of messages in the receive buffer
   * 
   * @param buffer_id ID of the rx buffer
   * 
   * @return const unsigned int Number of messages in buffer
   */
  const unsigned int getNumRxMessages(const unsigned int buffer_id);

  /**
   * @brief Get message from rx buffer
   * 
   * @param buffer_id ID of the rx buffer
   * @param rx_msg Received message
   * 
   * @return @ref Result
   */
  const Result getRxMessage(const unsigned int buffer_id,
                            CANMsg& rx_msg);

  /**
   * @brief Check if rx buffer is overflowed
   * 
   * @param buffer_id ID of the rx buffer
   * 
   * @return true Overflow detected
   * @return false No overflow detected
   */
  const bool checkBufferOverflow(const unsigned int buffer_id);

  /**
   * @brief Clears the desired buffer
   * 
   * @param buffer_id ID of the rx buffer
   * 
   * @return @ref Result
   */
  const Result clearBuffer(const unsigned int buffer_id);

  /**
   * @brief Returns the state of the class
   * 
   * @return true init() was called successfully
   * @return false false() class is not initialized
   */
  const bool isInitialized(void) const;

#ifndef BUILD_TESTS
private:
#endif

  /**
   * @brief Opens a CAN socket and stores the ID to can_socket
   * 
   * @param can_socket ID of the socket
   * 
   * @return true Successfully opened socket
   * @return false Failed to open socket
   */
  const bool openSocket(int& can_socket);

  /** \brief Name of the can interface */
  std::string _if_name;

  /** \brief Linux Socket for sending can messages */
  int _tx_socket = -1;

  /** \brief Mutex for locking internal can socket */
  std::mutex _can_mutex;

  /** \brief List containing all rx buffers */
  std::vector<std::unique_ptr<CANRxBuffer>>  _rx_buffers;
  std::mutex _rx_buffer_mutex;

  /** \brief Logging option: set to true to enable logging */
  const bool _logging = false; 

  /** \brief Logging module name */
  const std::string _log_module = "CANInterface";

  /** \brief True class is initialized */
  std::atomic<bool> _is_initialized;
};

 /**
  * @} 
  */ // evo_mbed_tools_can
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_CAN_INTERFACE_H_ */