//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file FlashHexFile.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Representation of a HEX file used for firmware flashing
 * 
 * @version 1.0
 * @date 2019-08-20
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */


#ifndef EVO_MBED_TOOLS_FLASH_HEX_FILE_H_
#define EVO_MBED_TOOLS_FLASH_HEX_FILE_H_

/* Includes ----------------------------------------------------------------------*/

#include <evo_mbed/bootloader/ProductID.h>
#include <evo_mbed/bootloader/BootloaderDefs.h>

#include <string.h>
#include <fstream>
#include <iomanip>
#include <map>
#include <boost/crc.hpp>
#include <vector>

/*--------------------------------------------------------------------------------*/

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup Flashing_Module
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup FlashHexFile
  * @{
  */
 
 /**
  * @brief Function codes of firmware hex file
  */
enum HexFunctionCode
{
  HEX_FC_DATA       = 0x00u, //!< Data record containing bytes
  HEX_FC_EOF        = 0x01u, //!< EOF record
  HEX_FC_EXT_ADDR   = 0x04u, //!< Extended address record
  HEX_FC_EVO_PID    = 0x20u, //!< Evocortex product ID
  HEX_FC_UNKNOWN    = 0xFFu  //!< Unknown function code
};

/**
 * @brief Class representing HEX-File used for flashing
 * 
 # Overview

 TODO Add description of class

 * 
 */
class FlashHexFile
{
public:

  /**
   * @brief Default constructor
   * 
   * @param  logging Enables/disabled log output
   */
  FlashHexFile(const bool logging = false);

  /**
   * @brief Destructor
   * 
   */
  ~FlashHexFile();

  /**
   * @brief Opens the specified file
   * 
   * @param filename Filename including path
   * 
   * @return true Success
   * @return false Error
   */
  bool open(const std::string& filename);

  /**
   * @brief Closes the hex file
   */
  void close(void);

  /**
   * @brief Modifies the byte in the hex file at the specified address
   * 
   * @param address 32-bit address where byte is written
   * @param byte Value to write
   * @return true Byte successfully modified
   * @return false Failed to modify byte
   */
  bool setProgramByte(const uint32_t address, const uint8_t byte);

  /**
   * @brief Reads a byte from the program at the desired address
   * 
   * @param address 32-bit address from where byte is readed
   * @param byte Reference to variable wwere byte is written too
   * @return true Byte found in program
   * @return false Byte not found in program
   */
  bool getProgramByte(const uint32_t address, uint8_t& byte) const;

  /**
   * @brief Reads a word from the program at the desired address
   *        if the address is not found the byte is set to 0xFF
   * 
   * @param address 32-bit address from where word is readed
   * @param word Reference to variable where byte is written too
   * 
   * @return true Success
   * @return false Program empty
   */
  bool getProgramWord(const uint32_t address, uint32_t& word) const;

  /**
   * @brief Get the 32-bit address of the first byte in the program
   * 
   * @return const uint32_t Address of first byte
   */
  uint32_t getProgramFirstAddr(void) const;

  /**
   * @brief Get the 32-bit address of the last byte in the program
   * 
   * @return const uint32_t Address of last byte
   */
  uint32_t getProgramLastAddr(void) const;

  /**
   * @brief Get the size of the complete program in bytes
   *        Including CONST and APP area
   * 
   * @return const uint32_t Program size in bytes
   */
  uint32_t getProgramSizeBytes(void) const;

  /**
   * @brief Get the size of the app in bytes excluding
   *        the CONST are of the program
   * 
   * @return const uint32_t 
   */
  uint32_t getAppSizeBytes(void) const;

  /**
   * @brief Get the product type the firmware is for
   * 
   * @return const ProductType @ref ProductType
   */
  ProductType getProductType(void) const;

  /**
   * @brief Get the CRC of the application
   * 
   * @return const uint32_t CRC value
   */
  uint32_t getCRC(void) const;


private:

  /**
   * @brief Read hex file
   * 
   * @return true Success
   * @return false Error
   */
  bool readHexFile(void);

  /**
   * @brief Read a complete line and perform CRC to
   *        check if its valid
   * 
   * @param code Function code @ref HexFunctionCode
   * @param address Address of data 
   * @param data List containing data readed
   * 
   * @return true Success
   * @return false Error
   */
  bool readLine(const std::string& line,
                      HexFunctionCode& code,
                      uint16_t& address,
                      std::vector<uint8_t>& data);

  /**
   * @brief Checks if the program is valid and loads further information
   *        like the software version and the CRC of the program
   * 
   * @return true Program valid
   * @return false Program invalid
   */
  bool checkProgramVld(void);

  /**
   * @brief Calculates CRC32 value from @ref start
   *        to @ref stop address of the program code
   * 
   * @param start Start address in program code
   * @param stop Stop address in program code
   * 
   * @return const uint32_t CRC32 value
   */
  uint32_t calCRC32(const uint32_t start,
                    const uint32_t stop);

  /** \brief File containing program code */
  std::ifstream   _file;

  /** \brief Product type program is written for */
  ProductType     _product_type;

  /** \brief Software version of program */
  float           _version;

  /** \brief CRC32 value of program code */
  uint32_t        _crc;

  /** \brief Mapp storing address (32-bit) and byte (8-bit) of program code */
  std::map<uint32_t, uint8_t>   _program_code_bytes;

  /** \brief Program code in bytes (CONST and APP area) */
  uint32_t  _program_code_size;

  /** \brief Size of APP area of program code in bytes */
  uint32_t  _app_code_size;

  /** \brief Logging option: set to true to enable logging */
  const bool _logging = false; 

  /** \brief Logging module name */
  const std::string _log_module = "FlashHexFile";

  /** \brief State of file (open:true, closed:false) */
  bool  _is_open;
};

 /**
  * @} 
  */ // FlashHexFile
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // Flashing_Module
/*--------------------------------------------------------------------------------*/

  /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

};

#endif /* EVO_MBED_TOOLS_FLASH_HEX_FILE_H_ */