//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file evo_mbed/Utils.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief General defines and utilities - Linking File
 * 
 * @version 1.0
 * @date 2020-01-14
 * 
 * @copyright Copyright (c) 2020 Evocortex GmbH
 * 
 */

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/utils/Utils.h>
/*--------------------------------------------------------------------------------*/

