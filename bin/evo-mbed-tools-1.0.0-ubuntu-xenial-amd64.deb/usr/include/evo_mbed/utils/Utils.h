//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file utils/Utils.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief General defines and utilities
 * 
 * @version 1.0
 * @date 2018-12-17
 * 
 * @copyright Copyright (c) 2018 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_UTILS_H_
#define EVO_MBED_UTILS_H_

/* Includes ----------------------------------------------------------------------*/

#if defined(MCU_BUILD)
  #include <EvoMbedConf.h>
#endif

#include <cstdint>
#include <limits>
#include <array>
#include <math.h>
#include <stdbool.h>
/*--------------------------------------------------------------------------------*/

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup Utils
  * @{
  */

/**
 * @brief Results of evo_mbed functions used by most sub functions
 */
enum Result
{
  RES_OK              = 0x0000U,  //!< OK
  RES_ERROR           = 0x0001U,  //!< General Error
  RES_HAL_ERROR       = 0x0002U,  //!< Error caused by STM HAL Library
  RES_NOT_INITIALIZED = 0x0003U,  //!< Error: Component is not initialized
  RES_ALREADY_CALLED  = 0x0004U,  //!< Error: Function was already called (e.g. Init() called twice -> call DeInit() first)
  RES_INVALID_PARAMS  = 0x0005U,  //!< Error: Invalid functions set
  RES_OUT_OF_MEMORY   = 0x0006U,  //!< Error: Out of memory (e.g. no space left in an array)
  RES_NO_NEW_DATA     = 0x0007U,  //!< Warning: No new data available (e.g. no new CAN message received)
  RES_COND_NOT_MET    = 0x0008U,  //!< Warning: Conditions not met to call this function successfully
  RES_TIMEOUT         = 0x0009U,  //!< Error: Timeout while processing 
  RES_BUSY            = 0x000AU,  //!< Warning: Device is busy and command cannot be executed
  RES_CRIT_ERROR      = 0xFFFAU   //!< Critical Error
};

/**
 * @brief Namespace of evocortex utils
 */
namespace utils
{

/**
 * @brief This functions check if a bit is set in the bit field
 * 
 * @param bit_pos Bit Position (Starting from 0 = 1 Bit)
 * @param bit_field Bit field containing bits
 * @return true Bit is set
 * @return false Bit is not set
 */
inline const bool IsBitSet(const std::uint8_t bit_pos, const std::uint8_t bit_field)
{
  return static_cast<bool>((bit_field & (1U << bit_pos)) >> bit_pos);
}

/**
 * @brief Get the system time in milliseconds
 * 
 * The system tick is incremented every milliseconds. 
 * The maximum value is 2^32 - 1. Overflow after ca. 49 days.
 * 
 * @return const std::uint32_t System Time
 */
inline const std::uint32_t GetSysTimeMSec(void)
{
#if defined(USE_HAL_DRIVER)
  return HAL_GetTick();
#else
  return 0;
#endif
}

/**
 * @brief Get the system time in seconds
 * 
 * @return const float System time in seconds (ms accuracy)
 */
inline const float GetSysTimeSec(void)
{
#if defined(USE_HAL_DRIVER)
  return static_cast<float>(HAL_GetTick()) * 0.001f;
#else
  return 0.0f;
#endif
}

/**
 * @brief Calculate delta of two u16 value (overflow safe) = a - b
 */
inline const int32_t CheckU16Ovf(const int32_t value)
{
  if(value < -0x7FFF) {
    return value + 0xFFFF;
  }
  else if(value > 0x7FFF) {
    return value - 0xFFFF;
  }

  return value;
}

}

/**
 * @brief This makro calls the function (x) and stores its result
 *        if the result is != to RES_OK the makro exits the function
 *        with the result as return value
 */
#define EVO_RET_RESLT_ON_ERR(x)              \
{                                            \
  const evo_mbed::Result res_ret_on_err = x; \
  if(evo_mbed::RES_OK != res_ret_on_err)     \
  {                                          \
    return res_ret_on_err;                   \
  }                                          \
}                                            \

 /**
  * @} 
  */ // Utils
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

}; /* evo */

#endif /* EVO_MBED_UTILS_H_ */

