//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file Version.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Version of evo mbed tools library
 * 
 * @version 1.0
 * @date 2020-06-08
 * 
 * @copyright Copyright (c) 2020 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_TOOLS_VERSION_H_
#define EVO_MBED_TOOLS_VERSION_H_

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

 /** @addtogroup Version
  * @{
  */

/** \brief Complete Version String */
#define EVO_MBED_TOOLS_VER            "1.0.1"

/** \brief Major Version Number */
#define EVO_MBED_TOOLS_VER_MAJOR      1

/** \brief Minor Version Number */
#define EVO_MBED_TOOLS_VER_MINOR      0

/** \brief Patch Number */
#define EVO_MBED_TOOLS_VER_PATCH      1

/** \brief Devel state (TRUE: Devel Build, FALSE: Release Build) */
#define EVO_MBED_TOOLS_DEVEL_BUILD    0

/** \brief Git commit ID */
#define EVO_MBED_TOOLS_COMMIT_ID      b1cef35142bd62ebe822be233d3d5b45ef7bdfb3

#if (EVO_MBED_TOOLS_DEVEL_BUILD == 1)
  #warning("evo-mbed library is in devel state") 
#endif

 /**
  * @} 
  */ // Version

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_VERSION_H_ */
