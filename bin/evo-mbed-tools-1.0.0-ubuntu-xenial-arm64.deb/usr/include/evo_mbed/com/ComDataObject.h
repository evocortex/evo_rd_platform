//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file ComDataObject.h
 * @author MBA (info@evocortex.com)
 * @brief Communication data object
 * 
 * @version 1.0
 * @date 2019-04-13
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */

#ifndef EVO_MBED_COM_DATA_OBJECT_H_
#define EVO_MBED_COM_DATA_OBJECT_H_

/* Includes ----------------------------------------------------------------------*/
#include <evo_mbed/com/ComDefs.h>

#ifndef BUILD_MCU
  #include <mutex>
  #include <atomic>
#endif
/*--------------------------------------------------------------------------------*/
namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup COM_Module
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup COM_DataObject
  * @{
  */

/**
 * @brief Communication data object representation
 * 
 
  # Communication Data Object

  ## Overview

  A communication data object is used for reading and writing data between devices. 
  The data object can be configured to store “normal” data types like unsigned int, int and float. 
  The data size is limited to four bytes. 
  Every data object needs a unique ID to identify the object. 
  The class implements man read and write function to simplify the interaction with the data object class.

  This class is thread save when not compiled for MCU.

  ## Application

  ### Initialization/Configuration

  A data object must be constructed with a unique ID, the access type (read-only?) and the data type. 
  These values/settings are constant variables and cannot be changed without destructing the object.

  In the following example a data object with the ID 100001, write access and data type of bool
  will be initialized. The data type can be specified directly via @ref ComDataType or indirect
  with the init value. 

  ```
  // Initialize the communication object 'enable drive' with the unique ID
  // 10001, write access and boolean data type with init value of 'false'
  ComDataObject enable_drive(10001, true, false);

  // Initialize the communication object 'drive type' with the unique ID
  // 10002, write access and unsigned int data type with 1 byte.
  ComDataObject drive_type(10002, true, uint8_t(0));

  // Alternative
  ComDataObject drive_type(10002, true, COM_DATA_TYPE_U8);

  ```

  ### Read/Write Access

  In general all configuration data and values are accessible via getters (see class description for more details).

  To read the data value of the object a simple equal operator can be used.

  ```
  // Will read the value of drive_type. Take care with different data types.
  const uint8_t current_drive_type = drive_type;
  ```

  Please take care when mixing data types. For example do not assign a float data object to
  a integer. The cast will not lead to errors but the value may not be correct!

  If you want to assign a value to the data object it can also be done via the equal operator.

  ```
  // Will write the value to the data object
  drive_type = 6u;
  ```

  ### Data Object State

  A special flag is used to describe the state of the data object. 
  For example: If the server writes a new value to the client data object ‘drive_type’, 
  the data updated flag will be set by the communication handler. It can be checked via the function @ref getDataUpdated.
  The flag is set to false if data is readed via equal operator or the @ref setDataReaded function is called.

  ```
  // Check if new data was written by the server
  if(drive_type.getDataUpdated()) {
    // The read access will clear the data updated flag
    uint8_t new_drive_type = drive_type;

    // Do something fancy ...
  }
  ```

 */
class ComDataObject
{
public:

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param data_type Data type of the object
   */
  ComDataObject(const uint16_t id, const bool rw, const ComDataType data_type);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const bool initial_value);
  
  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint8_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int8_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint16_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int16_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const uint32_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const int32_t initial_value);

  /**
   * @brief Construct a new communication data object
   * 
   * @param id CAN object ID [0; 65535]
   * @param rw Object read and writable (true: yes, false: read only)
   * @param initial_value Initial value
   */
  ComDataObject(const uint16_t id, const bool rw, const float initial_value);

  /**
   * @brief Copy constructor
   * 
   * @param obj Root object
   * 
   */
  ComDataObject(const ComDataObject& obj);

  /**
   * @brief Set the Raw Bytes object
   * 
   * @param byte_list Pointer to array containing data
   * @param size Size of data in array
   */
  void setRawBytes(const uint8_t* byte_list, const uint8_t size);

  /**
   * @brief Sets the data updated flag to true
   */
  void setDataUpdated(void);

  /**
   * @brief Reset data updated flag
   */
  void setDataReaded(void);

  /**
   * @brief Returns the size of the used data type
   * 
   * @return const uint8_t Size of the object in bytes
   */
  const uint8_t getSize() const;

  /* Set operators */
  ComDataObject& operator=(const bool v);     //!< Set value
  ComDataObject& operator=(const uint8_t v);  //!< Set value
  ComDataObject& operator=(const int8_t v);   //!< Set value
  ComDataObject& operator=(const uint16_t v); //!< Set value
  ComDataObject& operator=(const int16_t v);  //!< Set value
  ComDataObject& operator=(const uint32_t v); //!< Set value
  ComDataObject& operator=(const int32_t v);  //!< Set value
  ComDataObject& operator=(const float v);    //!< Set value

  /* Get operators */
  operator bool();      //!< Get value and set data updated to flase
  operator uint8_t();   //!< Get value and set data updated to flase
  operator int8_t();    //!< Get value and set data updated to flase
  operator uint16_t();  //!< Get value and set data updated to flase
  operator int16_t();   //!< Get value and set data updated to flase
  operator uint32_t();  //!< Get value and set data updated to flase
  operator int32_t();   //!< Get value and set data updated to flase
  operator float();     //!< Get value and set data updated to flase

  /* Getters */
  const uint16_t      getID(void)           const;  //!< Get object ID
  const bool          getRW(void)           const;  //!< Get Read/Write enabled flag
  const ComDataType   getType(void)         const;  //!< Get data type
  const bool          getDataUpdated(void)  const;  //!< Get data updated flag
  const uint32_t      getRawValue(void)     const;  //!< Get raw value

#ifndef BUILD_TESTS
private:
#endif

  const uint16_t      _id;        //!< CAN object ID [0; 65535]
  const bool          _rw;        //!< Read and writable (true: yes false: read only)
  const ComDataType   _type;      //!< Data type of the object

  ComDataDefine       _data;          //!< Data representation
  bool                _data_updated;  //!< True if data was written and not readed

#ifndef MCU_BUILD
  std::mutex          _access_mutex;  //!< Mutex for locking access in multi threaded environment
#endif
};

 /**
  * @} 
  */ // COM_DataObject
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // COM_Module
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

}; /* namespace evo_mbed */

#endif /* EVO_MBED_COM_DATA_OBJECT_H_ */
