//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file LimitedValue.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Limited Value Representation
 * 
 * @version 1.0
 * @date 2019-04-08
 * 
 * @copyright Copyright (c) 2019 Evocortex GmbH
 * 
 */



/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef EVO_MBED_LIMITED_VALUE_H_
#define EVO_MBED_LIMITED_VALUE_H_
/*----------------------------------------------------------------------------*/

/* Includes ------------------------------------------------------------------*/
#include <evo_mbed/utils/Utils.h>
/*----------------------------------------------------------------------------*/

namespace evo_mbed
{

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed
  * @{
  */

/*--------------------------------------------------------------------------------*/
/** @addtogroup Utils
  * @{
  */

/**
 * @brief Limited Value class
 * 
 * @tparam T Datatype of the limited value
 */
template <typename T>
class LimitedValue
{
public:
  /**
   * @brief Constructs a new object with std numeric limits
   */
  LimitedValue()  : _value(0),
                    _min(std::numeric_limits<T>::lowest()),
                    _max(std::numeric_limits<T>::max()) {limitValue();}

  /**
   * @brief Construct a new object with value
   * 
   * @param v Value to set
   */
  LimitedValue(const T v) :
                  _value(v),
                  _min(std::numeric_limits<T>::lowest()),
                  _max(std::numeric_limits<T>::max()) {limitValue();} 

  /**
   * @brief Construct a new object with limits
   * 
   * @param min Minimal allowed value
   * @param max Maximal allowed value
   */
  LimitedValue(const T min, const T max) :
                  _value(0),
                  _min(min),
                  _max(max) {}

  /**
   * @brief Constructs a new object with desired values
   * 
   * @param v Value to set
   * @param min Minimal allowed value
   * @param max Maximal allowed value
   */
  LimitedValue (const T v, const T min, const T max)  :
                  _value(v),
                  _min(min),
                  _max(max) {limitValue();}

  /**
   * @brief Sets a new value ( will automatically limited to min and max)
   * 
   * @param value New value to set
   */
  void setValue(const T value)  {_value = value; limitValue();}

  /**
   * @brief Sets the value only when in range 
   *        otherwise returns false and keeps old one
   * 
   * @param value Value to set
   * @return true Value is set to new value and in range
   * @return false Value is not set to new value (out of range)
   */
  const bool setValueInRange(const T value)
  {
    if(checkValue(value))
    {
      _value = value;
      return true;
    }
    return false;
  }

  /**
   * @brief Set minimal allowed value
   * 
   * @param min New minimal allowed value
   */
  void setMin(const T min)      {_min = min; limitValue();}

  /**
   * @brief Set maximal allowed value
   * 
   * @param max New maximal allowed value
   */
  void setMax(const T max)      {_max = max; limitValue();}

  /**
   * @brief Set min max limit
   * 
   * @param min Minimal allowed value
   * @param max Maximal allowed value
   */
  void setLimits(const T min, const T max)  {_min = min; _max = max; limitValue();}

  const T getValue()  const {return _value;}
  const T getMin()    const {return _min;}
  const T getMax()    const {return _max;}


  /* Typecast operator */
  operator T() const {return _value;}
  LimitedValue& operator=(const T& v) {setValue(_value = v); return *this;};

  /* Arithmetic operators LimitedValue A = LimitedValue B [X] T */
  const LimitedValue operator + (const T& v)
  {
    LimitedValue nlv(*this);
    nlv.setValue(nlv._value + v);
    return nlv;
  }

  const LimitedValue operator - (const T& v)
  {
    LimitedValue nlv(*this);
    nlv.setValue(nlv._value - v);
    return nlv;
  }

  const LimitedValue operator * (const T& v)
  {
    LimitedValue nlv(*this);
    nlv.setValue(nlv._value * v);
    return nlv;
  }

  const LimitedValue operator / (const T& v)
  {
    LimitedValue nlv(*this);
    nlv.setValue(nlv._value / v);
    return nlv;
  }

  /* Arithmetic Operators LimitedValue x= T() */
  LimitedValue& operator+=(const T& v) {setValue(_value += v); return *this;};
  LimitedValue& operator-=(const T& v) {setValue(_value -= v); return *this;};
  LimitedValue& operator*=(const T& v) {setValue(_value *= v); return *this;};
  LimitedValue& operator/=(const T& v) {setValue(_value /= v); return *this;};
  

private:

  /**
   * @brief Limits the value
   */
  void limitValue()
  {
    if(_value > _max)
    {
      _value = _max;
    }
    else if(_value < _min)
    {
      _value = _min;
    }
  }

  /**
   * @brief Checks if a value is in range
   * 
   * @param value Value to check
   * 
   * @return true Value is in range 
   * @return false Value is not in range
   */
  const bool checkValue(const T value)
  {
    if(value > _max || value < _min)
    {
      return false;
    }
    return true;
  }

  T     _value; //!< Current value
  T     _min;   //!< Minimal allowed value
  T     _max;   //!< Maximal allowed value
};


 /**
  * @} 
  */ // Utils
/*--------------------------------------------------------------------------------*/

 /**
  * @} 
  */ // evo_mbed
/*--------------------------------------------------------------------------------*/

}; /* namespace evo_mbed */  

#endif /* EVO_MBED_LIMITED_VALUE_H_ */
