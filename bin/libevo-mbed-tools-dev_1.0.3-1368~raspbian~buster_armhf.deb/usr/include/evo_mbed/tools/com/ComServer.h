//###############################################################
//# Copyright (C) 2019, Evocortex GmbH, All rights reserved.    #
//# Further regulations can be found in LICENSE file.           #
//###############################################################

/**
 * @file ComServer.h
 * @author MBA (info@evocortex.com)
 * 
 * @brief Communication Server Interface
 * 
 * @version 1.0
 * @date 2019-10-09
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef EVO_MBED_TOOLS_COM_SERVER_H_
#define EVO_MBED_TOOLS_COM_SERVER_H_

/* Includes ----------------------------------------------------------------------*/

#include <map>

#include <evo_mbed/com/ComDefs.h>
#include <evo_mbed/com/ComDataObject.h>

#include <evo_mbed/tools/can/CANInterface.h>

/*--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools
  * @{
  */

 namespace evo_mbed
 {

/*--------------------------------------------------------------------------------*/
/** @addtogroup evo_mbed_tools_com
  * @{
  */

constexpr unsigned int COM_SERVER_DEFAULT_COM_TIMEOUT_MS = 30U;
constexpr unsigned int COM_SERVER_DEFAULT_PING_TIMEOUT_MS = 1000U;
constexpr unsigned int COM_SERVER_RX_BUFFER_SIZE = 5U;

/**
 * @brief Communication Server for Embedded Devices
 * 

  # Overview

  TODO add description

 */
class ComServer
{
public:

  /**
   * @brief Constructor 
   * 
   * @param logging Set to true to enable logging output
   */
  explicit ComServer(bool logging = false);

  /**
   * @brief Destructor (releases if necessarry)
   */
  ~ComServer();

  /**
   * @brief Initializes the communication server
   * 
   * @param can_if_name Name of the can interface e.g. "slcan0"
   * @param com_timeout_ms Default timeout value for communication
   * 
   * @return @ref Result
   */
  Result init(const std::string& can_if_name,
                    unsigned int com_timeout_ms = COM_SERVER_DEFAULT_COM_TIMEOUT_MS);

  /**
   * @brief Releases components of communication server
   */
  void release();

  /**
   * @brief Registers a node id to the communication server
   *        This function has to be called before start()
   * 
   * @param node_id ID to add
   * @param ping_timeout_ms Maximum time to wait for response of ping message
   * @return @ref Result
   */
  Result registerNode(uint8_t node_id,
                      unsigned int ping_timeout_ms = COM_SERVER_DEFAULT_PING_TIMEOUT_MS);

  /**
   * @brief Reads a data object via SDO message
   * 
   * @param node_id ID of the client
   * @param object Object to read
   * @param com_error Communication error
   * @param retry_limit 
   * @param timeout_ms Timeout in milliseconds (0 = default timeout)
   * @param retry_limit Number of retries after timeout or communication error 
   * 
   * @return @ref Result 
   */
  Result readDataObject(uint8_t node_id,
                        ComDataObject& object,
                        ComMsgErrorCodes& com_error,
                        unsigned int timeout_ms = 0U,
                        unsigned int retry_limit = 0U);

  /**
   * @brief Write a data object via SDO message
   * 
   * @param node_id ID of the client
   * @param object Object to write
   * @param com_error Communication error
   * @param timeout_ms Timeout in milliseconds (0 = default timeout)
   * @return @ref Result 
   */
  Result writeDataObject(uint8_t node_id,
                         ComDataObject& object,
                         ComMsgErrorCodes& com_error,
                         unsigned int timeout_ms = 0U,
                         unsigned int retry_limit = 0U);

  /**
   * @brief Get the can interface
   *
   * @return Reference to @ref CANInterface 
   */
  CANInterface& getCANInterface();

  /** \brief Check if class is initialized */
  bool isInitialized() const;

#ifndef BUILD_TESTS
private:
#endif
  int getBufferID(uint8_t node_id);

  Result pingNode(uint8_t node_id, 
                  unsigned int timeout_ms);

  Result txSDO(uint8_t node_id,
               const ComCANMsg& sdo);

  Result rxSDO(uint8_t node_id,
               ComCANMsg& sdo,
               ComMsgErrorCodes& error_code,
               unsigned int timeout_ms);


  CANInterface  _can_if;
  std::map<uint8_t, int> _rx_buffer_list;
  std::mutex             _rx_buffer_list_mut;

  unsigned int _com_timeout_ms = COM_SERVER_DEFAULT_COM_TIMEOUT_MS;

  const bool _logging = false; 
  const std::string _log_module = "ComServer";

  std::atomic<bool> _is_initialized;
};

 /**
  * @} 
  */ // evo_mbed_tools_com
/*--------------------------------------------------------------------------------*/

}; /* evo_mbed */

 /**
  * @} 
  */ // evo_mbed_tools
/*--------------------------------------------------------------------------------*/

#endif /* EVO_MBED_TOOLS_COM_SERVER_H_ */